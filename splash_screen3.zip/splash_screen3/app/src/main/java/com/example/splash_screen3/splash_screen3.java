package com.example.splash_screen3;

import androidx.appcompat.app.AppCompatActivity;
import


public class splash_screen3 extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splashscreen);
         new Handler().postDelayed(new Runnable() {
             @Override
             public void run() {
                 Intent i = new Intent(packageContext:splash_screen3.this, MainActivity.class);
                 startActivity(i);
                 finish();
             }
         },       dailyMillis:4000);

    }
}